main :: IO ()
main = putStrLn "Hello, Haskell!"
main :: IO () is a type signature. It declares that main is an action in the IO (Input/Output) world, and that it doesn’t return any meaningful value (that’s what () means — an empty tuple).
main = putStrLn "Hello, Haskell!" is the definition. putStrLn is a function that prints a line of text to the screen.
