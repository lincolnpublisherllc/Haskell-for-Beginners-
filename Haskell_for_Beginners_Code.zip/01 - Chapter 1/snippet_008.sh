$ runhaskell Hello.hs
