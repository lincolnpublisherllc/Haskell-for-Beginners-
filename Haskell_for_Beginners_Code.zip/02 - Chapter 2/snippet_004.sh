ghc --version
