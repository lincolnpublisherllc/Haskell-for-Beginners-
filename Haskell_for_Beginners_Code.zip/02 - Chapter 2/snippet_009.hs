Open a terminal and type:
