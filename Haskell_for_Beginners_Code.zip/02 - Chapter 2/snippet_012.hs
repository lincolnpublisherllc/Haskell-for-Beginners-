True :: Bool
