In VS Code, create a new file called Hello.hs and type:
main :: IO ()
main = putStrLn "Hello, world from Haskell!"
