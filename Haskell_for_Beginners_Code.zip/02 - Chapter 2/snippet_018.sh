runhaskell Hello.hs
