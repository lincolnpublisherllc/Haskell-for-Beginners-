Open your terminal and type:
