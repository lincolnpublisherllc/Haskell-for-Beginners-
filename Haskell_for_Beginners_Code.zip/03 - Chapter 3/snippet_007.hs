42 :: Num p => p
