main :: IO ()
This is a type signature. It tells Haskell that main is an action in the IO world, meaning it does input/output. The () part means it doesn’t return a meaningful value (just an empty tuple, like “nothing to see here”).
main = putStrLn "Hello, Haskell!"
This is the definition of main. The function putStrLn prints a line of text to the screen, followed by a newline.
