Common beginner errors (missing do, wrong indentation).
