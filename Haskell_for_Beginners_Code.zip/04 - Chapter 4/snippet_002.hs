You create bindings in Haskell using let or where. Let’s start with let:
