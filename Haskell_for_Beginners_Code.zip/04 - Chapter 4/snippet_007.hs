Another way to create bindings is inside a function using where. For example:
areaOfCircle :: Float -> Float
