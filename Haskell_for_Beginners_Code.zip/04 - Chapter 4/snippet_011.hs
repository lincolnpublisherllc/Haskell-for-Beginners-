Here, rSquared is a binding local to the function. The where clause keeps the main formula clean while defining helper values below it.
Haskell’s type system is the foundation of its reliability. Let’s look at a few basic types:
