"hello" :: [Char]
