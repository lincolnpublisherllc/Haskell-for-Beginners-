You can (and should) give your bindings explicit type annotations. For example:
x :: Int
