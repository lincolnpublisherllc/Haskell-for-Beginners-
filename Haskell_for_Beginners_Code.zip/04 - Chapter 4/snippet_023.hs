This tells Haskell, “x is an Int, and its value is 42.” If you accidentally assign the wrong type, Haskell will catch it at compile time.
x :: Int
