Here’s where Haskell shines: you don’t have to write type annotations all the time. Haskell can usually infer them.
