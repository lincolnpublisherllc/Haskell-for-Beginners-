y :: Fractional a => a
What’s happening here? Haskell is saying: “y is some type that belongs to the Fractional family — like Float or Double.” It hasn’t committed to one yet, which gives your code flexibility.
This is type inference: Haskell figures out the types automatically, often more precisely than humans would. Still, best practice is to include type signatures for top-level definitions.
In dynamic languages like JavaScript or Python, type errors often appear only when you run the program. In Haskell, they’re caught at compile time. For example:
