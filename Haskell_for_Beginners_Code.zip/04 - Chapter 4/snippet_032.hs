 Exercise 2: Define a function square that takes an Int and returns its square, using a where clause for clarity.
 Exercise 3: Try letting Haskell infer the type of z = [1, 2, 3]. Use :t z to see what type it assigns.
