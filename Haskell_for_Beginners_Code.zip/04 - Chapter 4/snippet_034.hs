More on polymorphism (e.g., id :: a -> a)
