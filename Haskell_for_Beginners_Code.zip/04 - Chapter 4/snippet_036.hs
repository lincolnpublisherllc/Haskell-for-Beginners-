A “Try It Yourself” challenge: building a simple temperature converter that demonstrates bindings and type inference
