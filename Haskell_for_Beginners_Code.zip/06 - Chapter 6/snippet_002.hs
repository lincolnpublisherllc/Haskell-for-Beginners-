absolute :: Int -> Int
