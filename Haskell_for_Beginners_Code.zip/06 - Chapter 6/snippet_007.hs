When you have multiple conditions, nested if statements get messy. That’s where guards shine. Guards let you write conditions in a clean, vertical style:
grade :: Int -> String
