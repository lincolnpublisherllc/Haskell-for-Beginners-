For branching based on the structure of a value, Haskell provides the case expression. It looks similar to switch in other languages, but it’s more powerful:
describeList :: [a] -> String
describeList xs = case xs of
    []      -> "The list is empty."
    [x]     -> "The list has one element."
    [x,y]   -> "The list has two elements."
    _       -> "The list has many elements."
