This example introduces an important principle: patterns aren’t just conditions — they describe the very shape of data.
One of Haskell’s most elegant features is that you can pattern-match directly in function definitions. Instead of writing case inside the function, you split the definition into multiple clauses:
factorial :: Int -> Int
