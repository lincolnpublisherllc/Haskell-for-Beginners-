sumList :: [Int] -> Int
