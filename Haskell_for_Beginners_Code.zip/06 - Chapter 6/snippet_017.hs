This pattern — base case + recursive case — is one of the most common idioms in Haskell.
 Exercise 1: Write a function signumInt :: Int -> String that returns "Negative", "Zero", or "Positive" depending on the input. Try it first with if, then rewrite with guards.
 Exercise 2: Write a function headOrDefault :: [a] -> a -> a that returns the first element of a list, or a default value if the list is empty. Use case for the implementation.
 Exercise 3: Write a recursive function countElements :: [a] -> Int that counts the number of elements in a list using pattern matching.
