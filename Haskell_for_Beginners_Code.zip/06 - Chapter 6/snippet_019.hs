Deeper exploration of pattern matching on tuples and custom data types
Comparing if, guards, and case for readability
