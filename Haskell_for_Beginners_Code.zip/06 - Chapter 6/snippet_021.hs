End-of-chapter “Try It Yourself” challenge: implement a simple rock–paper–scissors game where user input is matched against possible outcomes with pattern matching
