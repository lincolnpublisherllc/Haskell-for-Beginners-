double :: Int -> Int
