This function takes two Ints and returns an Int. Note how the type is written: Int -> Int -> Int. You can think of it as:
