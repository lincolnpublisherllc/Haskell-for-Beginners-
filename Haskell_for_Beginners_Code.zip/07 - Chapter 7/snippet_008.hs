In imperative languages, you use loops (for, while) to repeat actions. Haskell doesn’t have these constructs. Instead, it uses recursion — functions that call themselves — to process data repeatedly.
factorial :: Int -> Int
