The first line defines the base case: factorial of 0 is 1.
The second line defines the recursive case: factorial of n is n * factorial (n - 1).
