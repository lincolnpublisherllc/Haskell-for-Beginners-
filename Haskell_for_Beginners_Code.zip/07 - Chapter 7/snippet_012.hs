myLength :: [a] -> Int
