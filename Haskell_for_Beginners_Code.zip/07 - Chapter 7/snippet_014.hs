applyTwice :: (a -> a) -> a -> a
