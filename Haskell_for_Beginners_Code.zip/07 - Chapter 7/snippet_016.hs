Prelude> map (*2) [1,2,3]
