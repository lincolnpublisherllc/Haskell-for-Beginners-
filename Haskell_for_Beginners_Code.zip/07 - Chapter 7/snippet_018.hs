 Exercise 1: Write a function triple :: Int -> Int that triples a number. Test it with applyTwice triple 2.
 Exercise 2: Write a recursive function sumList :: [Int] -> Int that sums all numbers in a list.
