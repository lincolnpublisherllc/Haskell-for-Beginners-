You can build lists with the cons operator ::
