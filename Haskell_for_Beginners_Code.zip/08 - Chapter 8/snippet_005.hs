mySum :: [Int] -> Int
