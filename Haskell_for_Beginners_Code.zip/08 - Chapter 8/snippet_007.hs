fst :: (a, b) -> a
