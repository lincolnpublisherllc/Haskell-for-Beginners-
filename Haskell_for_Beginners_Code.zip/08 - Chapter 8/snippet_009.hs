snd :: (a, b) -> b
