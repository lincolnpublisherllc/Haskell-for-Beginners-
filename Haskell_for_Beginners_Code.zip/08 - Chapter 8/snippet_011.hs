addPair :: (Int, Int) -> Int
