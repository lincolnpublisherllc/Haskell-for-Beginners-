Lists and tuples are nice, but what if you want to look up values by key? That’s where maps come in. Haskell provides this functionality through the Data.Map module.
First, import the module (qualified is best to avoid name clashes):
import qualified Data.Map as Map
phoneBook :: Map.Map String String
