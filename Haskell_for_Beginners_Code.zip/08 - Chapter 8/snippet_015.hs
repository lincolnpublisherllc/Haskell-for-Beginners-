 Exercise 1: Write a function safeHead :: [a] -> Maybe a that returns Nothing for an empty list and Just x for the first element.
 Exercise 2: Use a tuple to represent a 2D point (x,y) and write a function distance :: (Float, Float) -> (Float, Float) -> Float that calculates the distance between two points.
