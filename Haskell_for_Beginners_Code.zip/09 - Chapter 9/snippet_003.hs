Type errors happen when the compiler sees an expression that doesn’t “add up” type-wise. For example:
badAdd :: Int -> String -> Int
