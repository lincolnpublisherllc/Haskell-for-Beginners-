Prelude> (read "3" :: Int) + 4
