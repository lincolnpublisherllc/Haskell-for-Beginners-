Forgetting type signatures when they matter. Type inference is powerful, but sometimes Haskell needs a little help.
Haskell functions often use pattern matching. But if you forget to handle a case, Haskell will warn you — or even crash at runtime.
myHead :: [a] -> a
