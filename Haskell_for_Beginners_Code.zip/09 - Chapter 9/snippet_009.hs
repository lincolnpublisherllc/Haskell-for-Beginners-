myHeadSafe :: [a] -> Maybe a
