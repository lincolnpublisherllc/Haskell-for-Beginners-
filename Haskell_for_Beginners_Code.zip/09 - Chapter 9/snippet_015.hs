main = do { putStrLn "Hello"; putStrLn "World" }
This isn’t pretty, but it can help pinpoint where the indentation is wrong.
