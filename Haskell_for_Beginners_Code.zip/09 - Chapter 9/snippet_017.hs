Adding type signatures: clarifies your intent and makes errors easier to interpret.
 Exercise 1: Write a function safeDivide :: Int -> Int -> Maybe Int that returns Nothing when dividing by zero. Try leaving out the zero case and observe the error.
 Exercise 2: Introduce a deliberate type error ("hi" + 3) and read the compiler’s explanation carefully. Rewrite the expression correctly.
