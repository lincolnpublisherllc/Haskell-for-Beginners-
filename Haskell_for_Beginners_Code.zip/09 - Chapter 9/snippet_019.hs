More examples of tricky type errors (polymorphism, ambiguous types)
