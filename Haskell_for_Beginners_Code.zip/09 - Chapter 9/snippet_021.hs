More layout rules with nested let, where, and do blocks
End-of-chapter “Try It Yourself” challenge: debug a small, broken Haskell program by fixing type mismatches, adding missing patterns, and correcting indentation
