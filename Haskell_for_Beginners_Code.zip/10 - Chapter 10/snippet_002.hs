Designing a tiny data model
