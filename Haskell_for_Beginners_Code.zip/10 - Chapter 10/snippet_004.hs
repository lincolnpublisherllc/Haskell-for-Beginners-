Using Data.List and Data.Map where they help
