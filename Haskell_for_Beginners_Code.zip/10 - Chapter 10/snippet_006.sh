mkdir todo-cli
cd todo-cli
code Main.hs
