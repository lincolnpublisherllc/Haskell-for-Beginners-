main :: IO ()
main = putStrLn "To-Do CLI"
