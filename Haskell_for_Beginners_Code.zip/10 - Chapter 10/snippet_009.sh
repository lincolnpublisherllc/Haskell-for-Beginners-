runhaskell Main.hs
