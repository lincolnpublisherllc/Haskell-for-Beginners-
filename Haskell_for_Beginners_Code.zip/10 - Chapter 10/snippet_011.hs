data Task = Task
  { taskId      :: Int
  , description :: String
  , isDone      :: Bool
  } deriving (Show, Read, Eq)
Why deriving (Show, Read, Eq)?
