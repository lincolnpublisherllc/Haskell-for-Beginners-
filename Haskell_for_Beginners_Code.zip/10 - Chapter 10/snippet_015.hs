data Task = Task
  { taskId      :: Int
  , description :: String
  , isDone      :: Bool
  } deriving (Show, Read, Eq)
