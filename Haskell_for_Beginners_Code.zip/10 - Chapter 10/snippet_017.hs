nextId :: [Task] -> Int
