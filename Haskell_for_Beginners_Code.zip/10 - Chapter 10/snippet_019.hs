addTask :: String -> [Task] -> [Task]
