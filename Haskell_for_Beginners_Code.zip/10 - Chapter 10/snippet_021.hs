markDone :: Int -> [Task] -> [Task]
