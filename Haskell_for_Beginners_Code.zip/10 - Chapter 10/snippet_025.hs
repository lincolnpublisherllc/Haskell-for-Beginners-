removeTask :: Int -> [Task] -> [Task]
removeTask tid = filter (\t -> taskId t /= tid)
