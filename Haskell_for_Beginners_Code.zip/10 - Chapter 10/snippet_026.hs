formatTask :: Task -> String
