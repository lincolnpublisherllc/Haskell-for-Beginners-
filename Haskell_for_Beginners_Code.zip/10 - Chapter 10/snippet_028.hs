formatList :: [Task] -> String
