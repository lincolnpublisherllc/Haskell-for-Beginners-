loadTasks :: IO [Task]
loadTasks = do
