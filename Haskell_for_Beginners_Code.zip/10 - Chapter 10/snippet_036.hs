  case exists of
    Nothing   -> return []
    Just text ->
      case readMaybe text :: Maybe [Task] of
        Just ts -> return ts
        Nothing -> return []  -- If file is corrupted, start fresh.
