safeReadFile :: FilePath -> IO (Maybe String)
safeReadFile fp = do
