readFileIfExists :: FilePath -> IO (Maybe String)
readFileIfExists fp = do
