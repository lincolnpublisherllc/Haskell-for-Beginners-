readFile' :: FilePath -> IO (Maybe String)
readFile' fp = do
