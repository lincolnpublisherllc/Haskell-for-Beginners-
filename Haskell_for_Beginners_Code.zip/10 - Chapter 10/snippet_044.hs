After any command that modifies data, call saveTasks
