parseCommand :: String -> Command
