  case words input of
    []           -> cmdHelp
    ["list"]     -> cmdList
    ["quit"]     -> cmdQuit
    ["help"]     -> cmdHelp
    ("add":rest) ->
