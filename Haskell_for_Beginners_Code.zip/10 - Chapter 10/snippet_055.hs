    ["done", n]  ->
        case readMaybe n of
          Just k  -> cmdDone k
          Nothing -> cmdUnknown "done requires a number id"
    ["remove", n] ->
        case readMaybe n of
          Just k  -> cmdRemove k
          Nothing -> cmdUnknown "remove requires a number id"
    _            -> cmdUnknown "unknown command"
main :: IO ()
main = do
