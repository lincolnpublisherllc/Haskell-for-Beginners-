loop :: [Task] -> IO ()
loop tasks = do
