  case parseCommand line of
    cmdHelp -> do
