    cmdAdd desc -> do
