    cmdRemove tid -> do
