    cmdQuit -> do
