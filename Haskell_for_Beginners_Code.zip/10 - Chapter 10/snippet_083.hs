  case e of
    Nothing -> return []
    Just text ->
      case readMaybe text :: Maybe [Task] of
        Just ts -> return ts
        Nothing -> return []
