readFileSafe :: FilePath -> IO (Maybe String)
readFileSafe fp = do
  result <- E.try (readFile fp) :: IO (Either E.IOException String)
  case result of
    Left _    -> return Nothing
    Right txt -> return (Just txt)
