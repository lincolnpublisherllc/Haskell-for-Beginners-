data Task = ... defines your own type with named fields. Record syntax makes updates simple with { isDone = True }.
