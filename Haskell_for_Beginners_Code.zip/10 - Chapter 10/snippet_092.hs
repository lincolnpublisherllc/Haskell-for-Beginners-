Exercise 1. Add a command clear that removes all tasks that are done.
Hint: write a pure function clearDone :: [Task] -> [Task] using filter.
