data Priority = Low | Medium | High
  deriving (Show, Read, Eq, Ord)
