data Task = Task
  { taskId      :: Int
  , description :: String
  , isDone      :: Bool
  , priority    :: Priority
  } deriving (Show, Read, Eq)
