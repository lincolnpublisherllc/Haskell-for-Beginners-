Add a command listp that lists tasks sorted by priority, highest first.
Hint: import Data.List (sortOn) and use reverse (sortOn priority ts) or sortOn (Down . priority) with Data.Ord.
