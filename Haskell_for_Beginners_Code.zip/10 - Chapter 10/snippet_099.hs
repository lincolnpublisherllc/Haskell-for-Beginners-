Add type signatures for top-level functions. This helps the compiler give clearer messages and helps readers understand your intent.
