Misaligned indentation inside do blocks. Let your editor handle formatting and keep consistent spacing.
Letting IO leak into your logic. If a function does not need to do input or output, keep it pure.
