    cmdQuit -> putStrLn "Goodbye."
    cmdUnknown msg -> do
