  case m of
    Nothing -> return []
    Just txt ->
      case readMaybe txt :: Maybe [Task] of
        Just ts -> return ts
        Nothing -> return []
