readFileSafe :: FilePath -> IO (Maybe String)
readFileSafe fp = do
  r <- E.try (readFile fp) :: IO (Either E.IOException String)
  case r of
    Left _    -> return Nothing
    Right txt -> return (Just txt)
You now have a working mini project that uses real Haskell habits: small pure functions, a clear data model, safe parsing, and a recursive IO loop. Tweak it, extend it, and make it yours.
