Why it happens:
In Haskell, if is an expression, not a statement. It must produce a value in all cases. Without else, the compiler doesn’t know what to do when the condition is False.
