safeHead :: [a] -> Maybe a
