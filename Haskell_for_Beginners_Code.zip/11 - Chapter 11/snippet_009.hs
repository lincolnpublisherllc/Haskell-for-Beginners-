f :: (Int, Int) -> Int
