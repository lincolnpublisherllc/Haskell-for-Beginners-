The fix:
Handle every case:
factorial :: Int -> Int
