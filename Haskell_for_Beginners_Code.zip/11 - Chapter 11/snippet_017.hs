 Exercise 1: Intentionally write a function that forgets the empty list case. Load it and see the compiler warning. Then fix it.
