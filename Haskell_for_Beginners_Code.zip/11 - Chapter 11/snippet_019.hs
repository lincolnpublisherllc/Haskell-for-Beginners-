 Exercise 3: Write myAdd (x, y) = x + y and call it with myAdd 3 4. What error do you get? Fix the function so it works.
