End-of-chapter “Try It Yourself” challenge: take a deliberately broken mini-program and systematically fix type errors, pattern errors, and indentation
