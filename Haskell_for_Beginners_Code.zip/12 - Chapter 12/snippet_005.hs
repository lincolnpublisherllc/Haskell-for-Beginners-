42 :: Num p => p
That Num p => p wasn’t random noise. It was Haskell telling you:
“42 can be any type that belongs to the Num typeclass.”
A typeclass is a collection of types that share a common set of operations. Think of it as a contract: if a type is in a class, it promises to implement certain functions.
