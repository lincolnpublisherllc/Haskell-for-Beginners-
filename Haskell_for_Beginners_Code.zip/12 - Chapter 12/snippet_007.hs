read "42" :: Int   -- 42
