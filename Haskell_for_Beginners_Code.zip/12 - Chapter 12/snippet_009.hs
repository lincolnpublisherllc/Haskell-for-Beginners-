class Describable a where
  describe :: a -> String
This says: Any type a that belongs to Describable must implement a function describe.
Now let’s make a type an instance:
data Pet = Dog String | Cat String
