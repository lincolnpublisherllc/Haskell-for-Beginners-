Suppose you want to organize your to-do CLI project. Create a new file:
