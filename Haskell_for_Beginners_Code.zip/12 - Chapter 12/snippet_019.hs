module Task (...) where declares the module’s name and which functions are exported.
Task(..) exports the whole Task data type and its fields.
