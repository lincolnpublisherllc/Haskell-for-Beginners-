main :: IO ()
main = hspec $ do
  describe "addTask" $ do
    it "adds a new task to an empty list" $ do
