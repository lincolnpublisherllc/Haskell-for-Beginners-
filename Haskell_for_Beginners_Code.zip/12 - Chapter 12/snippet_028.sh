runhaskell Spec.hs
