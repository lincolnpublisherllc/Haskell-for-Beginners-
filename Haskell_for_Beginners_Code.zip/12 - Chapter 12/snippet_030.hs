 Exercise 1: Define a typeclass PrettyPrint with a function pretty :: a -> String. Make Task an instance.
 Exercise 2: Create a module MathUtils with a function square and import it into your main file.
