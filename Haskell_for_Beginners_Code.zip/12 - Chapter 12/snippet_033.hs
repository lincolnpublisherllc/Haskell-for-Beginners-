End-of-chapter “Try It Yourself” challenge: refactor the to-do CLI into modules, add a PrettyPrint typeclass for tasks, and write two automated tests
