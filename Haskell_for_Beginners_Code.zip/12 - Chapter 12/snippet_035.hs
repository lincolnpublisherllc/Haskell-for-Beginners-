Maybe: A type that represents an optional value (Just something or Nothing).
