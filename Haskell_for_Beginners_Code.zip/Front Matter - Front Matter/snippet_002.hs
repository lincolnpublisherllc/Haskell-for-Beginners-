You do not need prior programming experience. If you can follow simple instructions, read code slowly, and try small experiments, you will do well.
Read and write basic Haskell: bindings, expressions, functions, and type signatures.
Make decisions using if, guards, and case, and match patterns on lists and tuples.
Work with core data structures: lists, tuples, and key–value maps.
