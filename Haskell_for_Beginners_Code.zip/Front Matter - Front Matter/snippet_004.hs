A simple text editor. We use Visual Studio Code with the Haskell extension because it shows types, errors, and suggestions as you type.
