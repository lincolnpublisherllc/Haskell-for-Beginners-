Name things. A clear name and a short type signature do more for understanding than a paragraph of prose.
Let types guide you. When the compiler complains, read the message slowly. It usually tells you the mismatch and where it happened. Learning to read these messages is a skill you will use every day.
