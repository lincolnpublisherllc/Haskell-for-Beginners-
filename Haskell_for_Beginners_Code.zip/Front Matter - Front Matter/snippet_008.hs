We include type signatures for top-level functions.
