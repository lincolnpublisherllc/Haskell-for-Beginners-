42 :: Num p => p
Prelude> map (*2) [1,2,3]
