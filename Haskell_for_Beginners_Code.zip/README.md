# Haskell for Beginners — Extracted Code

_Generated on 2025-09-19 09:32:06 UTC_


This archive contains code and command/session snippets extracted chapter-by-chapter from the DOCX. 
File extensions are heuristic: `.hs` for Haskell, `.sh` for shell commands, and `.ghci.txt` for GHCi transcripts. 
Some inline examples may be included as `.txt` if their language could not be determined confidently.


## Front Matter — Front Matter

- `snippet_001.txt` — 
- `snippet_002.hs` — You do not need prior programming experience. If you can follow simple instructions, read code slowly, and try small ...
- `snippet_003.txt` — Build and run a small command-line project that separates pure logic from IO.
- `snippet_004.hs` — A simple text editor. We use Visual Studio Code with the Haskell extension because it shows types, errors, and sugges...
- `snippet_005.ghci.txt` — Read with your editor open. Type the examples, do not just skim them. When you see a snippet, run it in GHCi or as a ...
- `snippet_006.hs` — Name things. A clear name and a short type signature do more for understanding than a paragraph of prose.
- `snippet_007.txt` — Conventions in code
- `snippet_008.hs` — We include type signatures for top-level functions.
- `snippet_009.txt` — Prelude> :t 42
- `snippet_010.hs` — 42 :: Num p => p
- `snippet_011.txt` — [2,4,6]
- `snippet_012.hs` — Haskell is used in finance, compilers, developer tools, education, and research. The strongest reason to learn it, th...
- `snippet_013.txt` — You build a small command-line project.
- `snippet_014.ghci.txt` — Run code in GHCi line by line. If a large expression confuses you, assign parts to names and inspect their types with...
- `snippet_015.hs` — Add type signatures. They make error messages sharper and help you think clearly.

## 01 — Chapter 1

- `snippet_001.txt` — Imagine sitting in front of your computer with a spark of curiosity: I want to learn programming. You open a tutorial...
- `snippet_002.hs` — But what if there was a language that encouraged you to slow down, think clearly, and focus on the essence of your id...
- `snippet_003.txt` — Haskell was born in the late 1980s, a time when many new languages were appearing. Computer scientists wanted a pure ...
- `snippet_004.hs` — Strong, Static Typing — Haskell checks your program’s types at compile time. This acts like a grammar checker for cod...
- `snippet_005.txt` — Let’s not stay in theory too long. Here’s the simplest Haskell program you can write:
- `snippet_006.hs` — main :: IO ()
- `snippet_007.txt` — Save this in a file called Hello.hs and run:
- `snippet_008.sh` — $ runhaskell Hello.hs
- `snippet_009.txt` — Hello, Haskell!

## 02 — Chapter 2

- `snippet_001.txt` — The Glasgow Haskell Compiler (GHC) installed — this turns Haskell code into programs.
- `snippet_002.sh` — curl --proto '=https' --tlsv1.2 -sSf https://get-ghcup.haskell.org | sh
- `snippet_003.txt` — On Windows, download and run the official GHCup installer from:
- `snippet_004.sh` — ghc --version
- `snippet_005.txt` — The Glorious Glasgow Haskell Compilation System, version 9.6.3
- `snippet_006.sh` — cabal --version
- `snippet_007.txt` — cabal-install version 3.10.1.0
- `snippet_008.ghci.txt` — One of Haskell’s best learning tools is GHCi — an interactive REPL (Read–Eval–Print Loop). Think of it as a calculato...
- `snippet_009.hs` — Open a terminal and type:
- `snippet_010.ghci.txt` — ghci
- `snippet_011.txt` — Prelude>
- `snippet_012.hs` — True :: Bool
- `snippet_013.txt` — 2 + 3 evaluates to 5.
- `snippet_014.ghci.txt` — :t True asks GHCi for the type of True, which is Bool.
- `snippet_015.txt` — Prelude> :quit
- `snippet_016.ghci.txt` —  Exercise 1: In GHCi, calculate 10 * 5 - 7. What’s the result?
- `snippet_017.hs` — In VS Code, create a new file called Hello.hs and type:
- `snippet_018.sh` — runhaskell Hello.hs
- `snippet_019.txt` — Hello, world from Haskell!

## 03 — Chapter 3

- `snippet_001.ghci.txt` — Explore GHCi, the interactive environment where you can test ideas instantly.
- `snippet_002.txt` — Write your first Haskell program using main.
- `snippet_003.ghci.txt` — Most programming languages have a REPL (Read–Eval–Print Loop), an environment where you can type code, press Enter, a...
- `snippet_004.hs` — Open your terminal and type:
- `snippet_005.ghci.txt` — ghci
- `snippet_006.txt` — Prelude>
- `snippet_007.hs` — 42 :: Num p => p
- `snippet_008.txt` — 2 + 2 evaluates to 4.
- `snippet_009.ghci.txt` — :t 42 asks GHCi for the type of 42. Here, Haskell tells us 42 is a number (Num p => p) — we’ll unpack that later, but...
- `snippet_010.txt` — Prelude> :quit
- `snippet_011.hs` — main :: IO ()
- `snippet_012.sh` — runhaskell Hello.hs
- `snippet_013.txt` — Hello, Haskell!
- `snippet_014.hs` — main :: IO ()
- `snippet_015.txt` — putStrLn = “put string line”
- `snippet_016.hs` — main :: IO ()
- `snippet_017.txt` —     putStrLn "What is your name?"
- `snippet_018.sh` — $ runhaskell Hello.hs
- `snippet_019.txt` — What is your name?
- `snippet_020.ghci.txt` —  Exercise 3: In GHCi, try using reverse "Haskell" and see what happens.
- `snippet_021.txt` —  That’s Part 1 of Chapter 3 (about 700 words). Next, I can continue with:
- `snippet_022.ghci.txt` — More GHCi tricks (:load, :reload, :browse).
- `snippet_023.hs` — Common beginner errors (missing do, wrong indentation).
- `snippet_024.txt` — End-of-chapter challenge: a tiny “Greeter” program that asks for both name and age, then prints a personalized message.

## 04 — Chapter 4

- `snippet_001.txt` — # Python
- `snippet_002.hs` — You create bindings in Haskell using let or where. Let’s start with let:
- `snippet_003.txt` — Prelude> let x = 5
- `snippet_004.hs` — greeting :: String
- `snippet_005.txt` — greeting = "Hello, Haskell learner!"
- `snippet_006.ghci.txt` — If you load this into GHCi with :load MyFile.hs, you can use greeting just like a constant.
- `snippet_007.hs` — Another way to create bindings is inside a function using where. For example:
- `snippet_008.txt` — areaOfCircle r = pi * rSquared
- `snippet_009.hs` —   where
- `snippet_010.txt` —     rSquared = r * r
- `snippet_011.hs` — Here, rSquared is a binding local to the function. The where clause keeps the main formula clean while defining helpe...
- `snippet_012.txt` — Int: Fixed-size integer (like 42)
- `snippet_013.ghci.txt` — You can explore types in GHCi with the :t command:
- `snippet_014.txt` — Prelude> :t True
- `snippet_015.hs` — True :: Bool
- `snippet_016.txt` — 
- `snippet_017.hs` — 'a' :: Char
- `snippet_018.txt` — 
- `snippet_019.hs` — "hello" :: [Char]
- `snippet_020.txt` — Notice that "hello" is shown as [Char]. In Haskell, strings are actually lists of characters. We’ll explore lists in ...
- `snippet_021.hs` — You can (and should) give your bindings explicit type annotations. For example:
- `snippet_022.txt` — x = 42
- `snippet_023.hs` — This tells Haskell, “x is an Int, and its value is 42.” If you accidentally assign the wrong type, Haskell will catch...
- `snippet_024.txt` — x = "hello"   -- ERROR!
- `snippet_025.hs` — • Couldn't match expected type ‘Int’ with actual type ‘[Char]’
- `snippet_026.txt` — • In the expression: "hello"
- `snippet_027.hs` — Here’s where Haskell shines: you don’t have to write type annotations all the time. Haskell can usually infer them.
- `snippet_028.txt` — y = 3.14
- `snippet_029.hs` — y :: Fractional a => a
- `snippet_030.txt` — Prelude> "hello" + 3
- `snippet_031.ghci.txt` —  Exercise 1: In GHCi, bind a value name to your own first name and then use it in an expression like "Hello, " ++ name.
- `snippet_032.hs` —  Exercise 2: Define a function square that takes an Int and returns its square, using a where clause for clarity.
- `snippet_033.txt` —  That’s Part 1 of Chapter 4 (about 800 words). The full chapter would expand into:
- `snippet_034.hs` — More on polymorphism (e.g., id :: a -> a)
- `snippet_035.txt` — Comparing Haskell’s typing to Python/Java (with code examples)
- `snippet_036.hs` — A “Try It Yourself” challenge: building a simple temperature converter that demonstrates bindings and type inference

## 05 — Chapter 5

- `snippet_001.hs` — In Haskell, everything revolves around expressions. An expression is any piece of code that produces a value. Unlike ...
- `snippet_002.txt` — 2 + 3        -- evaluates to 5
- `snippet_003.hs` — (.+.) :: Int -> Int -> Int
- `snippet_004.txt` — x .+. y = (x + y) * 2
- `snippet_005.ghci.txt` — Now in GHCi:
- `snippet_006.txt` — Prelude> 3 .+. 4
- `snippet_007.ghci.txt` — Boolean expressions work the same way. Try these in GHCi:
- `snippet_008.txt` — Prelude> True && False
- `snippet_009.ghci.txt` —  Exercise 1: Rewrite 4 + 5 using prefix notation.
- `snippet_010.txt` —  That’s Part 1 of Chapter 5 (about 800 words).
- `snippet_011.ghci.txt` — End-of-chapter challenge: build a small “calculator” in GHCi using operators and functions

## 06 — Chapter 6

- `snippet_001.txt` — Every real-world program makes decisions. Should a user be allowed in? Is a number positive or negative? Which menu o...
- `snippet_002.hs` — absolute :: Int -> Int
- `snippet_003.txt` — absolute x = if x < 0
- `snippet_004.hs` — Notice a crucial difference: Haskell’s if always requires an else. Why? Because every expression in Haskell must eval...
- `snippet_005.ghci.txt` — Try it in GHCi:
- `snippet_006.txt` — Prelude> absolute (-5)
- `snippet_007.hs` — When you have multiple conditions, nested if statements get messy. That’s where guards shine. Guards let you write co...
- `snippet_008.txt` — grade score
- `snippet_009.hs` — For branching based on the structure of a value, Haskell provides the case expression. It looks similar to switch in ...
- `snippet_010.txt` — Here, the function describeList looks at a list and matches it against several possible patterns:
- `snippet_011.hs` — This example introduces an important principle: patterns aren’t just conditions — they describe the very shape of data.
- `snippet_012.txt` — factorial 0 = 1
- `snippet_013.hs` — sumList :: [Int] -> Int
- `snippet_014.txt` — sumList []     = 0
- `snippet_015.ghci.txt` — Test in GHCi:
- `snippet_016.txt` — Prelude> sumList [1,2,3,4]
- `snippet_017.hs` — This pattern — base case + recursive case — is one of the most common idioms in Haskell.
- `snippet_018.txt` —  That’s Part 1 of Chapter 6 (about 900 words).
- `snippet_019.hs` — Deeper exploration of pattern matching on tuples and custom data types
- `snippet_020.txt` — Common beginner mistakes (forgetting else, missing patterns, overlapping patterns)
- `snippet_021.hs` — End-of-chapter “Try It Yourself” challenge: implement a simple rock–paper–scissors game where user input is matched a...

## 07 — Chapter 7

- `snippet_001.txt` — In many languages, functions are optional. You can write an entire program without ever defining one — just string to...
- `snippet_002.hs` — double :: Int -> Int
- `snippet_003.txt` — double x = x * 2
- `snippet_004.hs` — add :: Int -> Int -> Int
- `snippet_005.txt` — add x y = x + y
- `snippet_006.hs` — This function takes two Ints and returns an Int. Note how the type is written: Int -> Int -> Int. You can think of it...
- `snippet_007.txt` — A function that takes an Int,
- `snippet_008.hs` — In imperative languages, you use loops (for, while) to repeat actions. Haskell doesn’t have these constructs. Instead...
- `snippet_009.txt` — factorial 0 = 1
- `snippet_010.hs` — The first line defines the base case: factorial of 0 is 1.
- `snippet_011.txt` — Prelude> factorial 5
- `snippet_012.hs` — myLength :: [a] -> Int
- `snippet_013.txt` — myLength []     = 0
- `snippet_014.hs` — applyTwice :: (a -> a) -> a -> a
- `snippet_015.txt` — applyTwice f x = f (f x)
- `snippet_016.hs` — Prelude> map (*2) [1,2,3]
- `snippet_017.txt` — [2,4,6]
- `snippet_018.hs` —  Exercise 1: Write a function triple :: Int -> Int that triples a number. Test it with applyTwice triple 2.
- `snippet_019.txt` —  Exercise 3: Use map to convert ["cat","dog","fish"] into ["CAT","DOG","FISH"]. (Hint: use the built-in function map ...

## 08 — Chapter 8

- `snippet_001.hs` — In Haskell, these structures are not just add-ons — they are central. Mastering lists, tuples, and maps will give you...
- `snippet_002.txt` — [1,2,3,4]              -- list of Int
- `snippet_003.hs` — You can build lists with the cons operator ::
- `snippet_004.txt` — Prelude> 1 : [2,3,4]
- `snippet_005.hs` — mySum :: [Int] -> Int
- `snippet_006.txt` — mySum []     = 0
- `snippet_007.hs` — fst :: (a, b) -> a
- `snippet_008.txt` — fst (x, _) = x
- `snippet_009.hs` — snd :: (a, b) -> b
- `snippet_010.txt` — snd (_, y) = y
- `snippet_011.hs` — addPair :: (Int, Int) -> Int
- `snippet_012.txt` — addPair (x,y) = x + y
- `snippet_013.hs` — Lists and tuples are nice, but what if you want to look up values by key? That’s where maps come in. Haskell provides...
- `snippet_014.txt` — phoneBook = Map.fromList
- `snippet_015.hs` —  Exercise 1: Write a function safeHead :: [a] -> Maybe a that returns Nothing for an empty list and Just x for the fi...
- `snippet_016.txt` —  Exercise 3: Create a map of three countries and their capitals. Write a function that takes a country and returns ei...

## 09 — Chapter 9

- `snippet_001.hs` — The type system and compiler act like a safety net. They refuse to let your program proceed if something doesn’t make...
- `snippet_002.txt` — Type errors — when you try to combine values in incompatible ways.
- `snippet_003.hs` — Type errors happen when the compiler sees an expression that doesn’t “add up” type-wise. For example:
- `snippet_004.txt` — badAdd x y = x + y
- `snippet_005.hs` — Prelude> (read "3" :: Int) + 4
- `snippet_006.txt` — 7
- `snippet_007.hs` — Forgetting type signatures when they matter. Type inference is powerful, but sometimes Haskell needs a little help.
- `snippet_008.txt` — myHead (x:_) = x
- `snippet_009.hs` — myHeadSafe :: [a] -> Maybe a
- `snippet_010.txt` — myHeadSafe []    = Nothing
- `snippet_011.hs` — main :: IO ()
- `snippet_012.txt` —     putStrLn "Hello"
- `snippet_013.hs` — main = do
- `snippet_014.txt` —     putStrLn "Hello"
- `snippet_015.hs` — main = do { putStrLn "Hello"; putStrLn "World" }
- `snippet_016.ghci.txt` — :t in GHCi: shows the type of an expression.
- `snippet_017.hs` — Adding type signatures: clarifies your intent and makes errors easier to interpret.
- `snippet_018.txt` —  That’s Part 1 of Chapter 9 (about 1,000 words).
- `snippet_019.hs` — More examples of tricky type errors (polymorphism, ambiguous types)
- `snippet_020.txt` — Detailed explanation of “non-exhaustive patterns” and how to avoid them with Maybe or Either
- `snippet_021.hs` — More layout rules with nested let, where, and do blocks

## 10 — Chapter 10

- `snippet_001.txt` — You have learned how to print text, read input, write functions, branch with guards and patterns, and work with lists...
- `snippet_002.hs` — Designing a tiny data model
- `snippet_003.txt` — Recursion in the main loop instead of traditional while/for loops
- `snippet_004.hs` — Using Data.List and Data.Map where they help
- `snippet_005.txt` — Basic file I/O with readFile and writeFile
- `snippet_006.sh` — mkdir todo-cli
- `snippet_007.hs` — module Main where
- `snippet_008.hs` — main :: IO ()
- `snippet_009.sh` — runhaskell Main.hs
- `snippet_010.txt` — To-Do CLI
- `snippet_011.hs` — data Task = Task
- `snippet_012.txt` — Show lets us print tasks during debugging.
- `snippet_013.hs` — module Main where
- `snippet_014.hs` — import Data.List (intercalate)
- `snippet_015.hs` — data Task = Task
- `snippet_016.txt` — Write the core logic as pure functions. This keeps IO at the edges.
- `snippet_017.hs` — nextId :: [Task] -> Int
- `snippet_018.txt` — nextId [] = 1
- `snippet_019.hs` — addTask :: String -> [Task] -> [Task]
- `snippet_020.txt` — addTask desc ts =
- `snippet_021.hs` — markDone :: Int -> [Task] -> [Task]
- `snippet_022.txt` — markDone tid = map mark
- `snippet_023.hs` —   where
- `snippet_024.txt` —     mark t | taskId t == tid = t { isDone = True }
- `snippet_025.hs` — removeTask :: Int -> [Task] -> [Task]
- `snippet_026.hs` — formatTask :: Task -> String
- `snippet_027.txt` — formatTask (Task tid desc done) =
- `snippet_028.hs` — formatList :: [Task] -> String
- `snippet_029.txt` — formatList [] = "(no tasks)"
- `snippet_030.hs` — saveFile :: FilePath
- `snippet_031.txt` — saveFile = "tasks.db"
- `snippet_032.hs` — saveTasks :: [Task] -> IO ()
- `snippet_033.txt` — saveTasks ts = writeFile saveFile (show ts)
- `snippet_034.hs` — loadTasks :: IO [Task]
- `snippet_035.txt` —   exists <- safeReadFile saveFile
- `snippet_036.hs` —   case exists of
- `snippet_037.txt` — 
- `snippet_038.hs` — safeReadFile :: FilePath -> IO (Maybe String)
- `snippet_039.txt` —   content <- readFileIfExists fp
- `snippet_040.hs` — readFileIfExists :: FilePath -> IO (Maybe String)
- `snippet_041.txt` —   -- We attempt to read and handle failure by returning Nothing.
- `snippet_042.hs` — readFile' :: FilePath -> IO (Maybe String)
- `snippet_043.txt` —   -- naive approach: attempt to read, if it fails the app stops.
- `snippet_044.hs` — After any command that modifies data, call saveTasks
- `snippet_045.txt` — On next run, try to load; if it fails, keep []
- `snippet_046.hs` — Users will type commands like:
- `snippet_047.txt` — add Buy milk
- `snippet_048.hs` — data Command
- `snippet_049.txt` —   = cmdAdd String
- `snippet_050.hs` —   deriving (Show, Eq)
- `snippet_051.hs` — parseCommand :: String -> Command
- `snippet_052.txt` — parseCommand input =
- `snippet_053.hs` —   case words input of
- `snippet_054.txt` —         let desc = unwords rest
- `snippet_055.hs` —     ["done", n]  ->
- `snippet_056.txt` —   putStrLn "To-Do CLI"
- `snippet_057.hs` — loop :: [Task] -> IO ()
- `snippet_058.txt` —   putStr "> "
- `snippet_059.hs` —   case parseCommand line of
- `snippet_060.txt` —       putStrLn helpText
- `snippet_061.hs` —     cmdList -> do
- `snippet_062.txt` —       putStrLn (formatList tasks)
- `snippet_063.hs` —     cmdAdd desc -> do
- `snippet_064.txt` —       let tasks' = addTask desc tasks
- `snippet_065.hs` —     cmdDone tid -> do
- `snippet_066.txt` —       let tasks' = markDone tid tasks
- `snippet_067.hs` —     cmdRemove tid -> do
- `snippet_068.txt` —       let tasks' = removeTask tid tasks
- `snippet_069.hs` —     cmdQuit -> do
- `snippet_070.txt` —       putStrLn "Goodbye."
- `snippet_071.hs` —     cmdUnknown msg -> do
- `snippet_072.txt` —       putStrLn ("Error: " ++ msg)
- `snippet_073.hs` — helpText :: String
- `snippet_074.txt` — helpText = unlines
- `snippet_075.sh` — runhaskell Main.hs
- `snippet_076.txt` — To-Do CLI
- `snippet_077.hs` — Right now the app always starts with an empty list. Let’s load tasks if a saved file exists. We will improve the earl...
- `snippet_078.txt` — saveFile = "tasks.db"
- `snippet_079.hs` — saveTasks :: [Task] -> IO ()
- `snippet_080.txt` — saveTasks ts = writeFile saveFile (show ts)
- `snippet_081.hs` — loadTasks :: IO [Task]
- `snippet_082.txt` —   e <- readFileSafe saveFile
- `snippet_083.hs` —   case e of
- `snippet_084.hs` — readFileSafe :: FilePath -> IO (Maybe String)
- `snippet_085.txt` — And in main:
- `snippet_086.hs` — main :: IO ()
- `snippet_087.txt` —   putStrLn "To-Do CLI"
- `snippet_088.hs` — data Task = ... defines your own type with named fields. Record syntax makes updates simple with { isDone = True }.
- `snippet_089.txt` — nextId scans the current list for the largest id and adds one. This is fine for small lists. A more advanced version ...
- `snippet_090.ghci.txt` — formatTask and formatList are renderers. Keeping them pure lets you test them easily in GHCi.
- `snippet_091.txt` — parseCommand uses words to split input. For more complex parsing you could use a library later, but this is enough to...
- `snippet_092.hs` — Exercise 1. Add a command clear that removes all tasks that are done.
- `snippet_093.txt` — Exercise 2. Add a command rename <id> <new text> that edits the description for a task.
- `snippet_094.hs` — data Priority = Low | Medium | High
- `snippet_095.hs` — data Task = Task
- `snippet_096.txt` — Update addTask to set a default priority, for example Medium.
- `snippet_097.hs` — Add a command listp that lists tasks sorted by priority, highest first.
- `snippet_098.txt` — Stretch goal: allow addp <Low|Medium|High> <description> to set priority at creation.
- `snippet_099.hs` — Add type signatures for top-level functions. This helps the compiler give clearer messages and helps readers understa...
- `snippet_100.txt` — Keep parseCommand explicit. Clear error messages beat clever parsing for beginners.
- `snippet_101.hs` — Misaligned indentation inside do blocks. Let your editor handle formatting and keep consistent spacing.
- `snippet_102.txt` — Add tags like @work or @home
- `snippet_103.ghci.txt` — Add simple tests for pure functions using ghci scripts or a test framework later
- `snippet_104.txt` — Below is a compact single-file version without priorities and with safe file loading via exceptions. Paste into Main....
- `snippet_105.hs` — module Main where
- `snippet_106.hs` — import Data.List (intercalate)
- `snippet_107.hs` — data Task = Task
- `snippet_108.hs` — data Command
- `snippet_109.txt` —   = cmdAdd String
- `snippet_110.hs` —   deriving (Show, Eq)
- `snippet_111.hs` — main :: IO ()
- `snippet_112.txt` —   putStrLn "To-Do CLI"
- `snippet_113.hs` — loop :: [Task] -> IO ()
- `snippet_114.txt` —   putStr "> "
- `snippet_115.hs` —   case parseCommand line of
- `snippet_116.txt` —       putStrLn helpText
- `snippet_117.hs` —     cmdList -> do
- `snippet_118.txt` —       putStrLn (formatList tasks)
- `snippet_119.hs` —     cmdAdd desc -> do
- `snippet_120.txt` —       let tasks' = addTask desc tasks
- `snippet_121.hs` —     cmdDone tid -> do
- `snippet_122.txt` —       let tasks' = markDone tid tasks
- `snippet_123.hs` —     cmdRemove tid -> do
- `snippet_124.txt` —       let tasks' = removeTask tid tasks
- `snippet_125.hs` —     cmdQuit -> putStrLn "Goodbye."
- `snippet_126.txt` —       putStrLn ("Error: " ++ msg)
- `snippet_127.hs` — helpText :: String
- `snippet_128.txt` — helpText = unlines
- `snippet_129.hs` — parseCommand :: String -> Command
- `snippet_130.txt` — parseCommand input =
- `snippet_131.hs` —   case words input of
- `snippet_132.txt` —       let desc = unwords rest
- `snippet_133.hs` —     ["done", n]  ->
- `snippet_134.hs` — nextId :: [Task] -> Int
- `snippet_135.txt` — nextId [] = 1
- `snippet_136.hs` — addTask :: String -> [Task] -> [Task]
- `snippet_137.txt` — addTask desc ts =
- `snippet_138.hs` — markDone :: Int -> [Task] -> [Task]
- `snippet_139.txt` — markDone tid = map mark
- `snippet_140.hs` —   where
- `snippet_141.txt` —     mark t | taskId t == tid = t { isDone = True }
- `snippet_142.hs` — removeTask :: Int -> [Task] -> [Task]
- `snippet_143.hs` — formatTask :: Task -> String
- `snippet_144.txt` — formatTask (Task tid desc done) =
- `snippet_145.hs` — formatList :: [Task] -> String
- `snippet_146.txt` — formatList [] = "(no tasks)"
- `snippet_147.hs` — saveFile :: FilePath
- `snippet_148.txt` — saveFile = "tasks.db"
- `snippet_149.hs` — saveTasks :: [Task] -> IO ()
- `snippet_150.txt` — saveTasks ts = writeFile saveFile (show ts)
- `snippet_151.hs` — loadTasks :: IO [Task]
- `snippet_152.txt` —   m <- readFileSafe saveFile
- `snippet_153.hs` —   case m of
- `snippet_154.hs` — readFileSafe :: FilePath -> IO (Maybe String)

## 11 — Chapter 11

- `snippet_001.hs` — When you first learn Haskell, the language can feel strict, even stubborn. You type something that looks perfectly fi...
- `snippet_002.txt` — Every mistake you make in Haskell teaches you something about its design. The key is to recognize common pitfalls ear...
- `snippet_003.hs` — Why it happens:
- `snippet_004.txt` — absolute x = if x < 0 then -x else x
- `snippet_005.hs` — safeHead :: [a] -> Maybe a
- `snippet_006.txt` — safeHead []    = Nothing
- `snippet_007.hs` — Found hole: _ :: ?
- `snippet_008.txt` — Why it happens:
- `snippet_009.hs` — f :: (Int, Int) -> Int
- `snippet_010.txt` — f (x, y) = x + y
- `snippet_011.hs` — The fix:
- `snippet_012.txt` — factorial n
- `snippet_013.hs` — main = do
- `snippet_014.txt` —     putStrLn "Hello"
- `snippet_015.hs` — main = do
- `snippet_016.txt` —     putStrLn "Hello"
- `snippet_017.hs` —  Exercise 1: Intentionally write a function that forgets the empty list case. Load it and see the compiler warning. T...
- `snippet_018.txt` —  Exercise 2: Try writing if x < 10 then "small" without an else. Read the error carefully. Add the missing else.
- `snippet_019.hs` —  Exercise 3: Write myAdd (x, y) = x + y and call it with myAdd 3 4. What error do you get? Fix the function so it wor...
- `snippet_020.txt` —  That’s Part 1 of Chapter 11 (about 1,000 words).
- `snippet_021.ghci.txt` — Real-world debugging strategies (breaking big expressions into smaller ones, using :t in GHCi, compiler warnings)
- `snippet_022.hs` — End-of-chapter “Try It Yourself” challenge: take a deliberately broken mini-program and systematically fix type error...

## 12 — Chapter 12

- `snippet_001.hs` — You’ve come a long way. Think back to Chapter 1, where Haskell’s syntax seemed alien: no mutable variables, no loops,...
- `snippet_002.txt` — But you may also feel there’s still a wide ocean ahead. You’re right — Haskell goes much deeper. The good news is tha...
- `snippet_003.ghci.txt` — You’ve already seen typeclasses at work, even if you didn’t realize it. Remember this in GHCi?
- `snippet_004.txt` — Prelude> :t 42
- `snippet_005.hs` — 42 :: Num p => p
- `snippet_006.txt` — Eq: types that can be compared for equality.
- `snippet_007.hs` — read "42" :: Int   -- 42
- `snippet_008.txt` — Here’s a beginner-friendly example:
- `snippet_009.hs` — class Describable a where
- `snippet_010.hs` — instance Describable Pet where
- `snippet_011.txt` —   describe (Dog name) = "A dog named " ++ name
- `snippet_012.hs` — Suppose you want to organize your to-do CLI project. Create a new file:
- `snippet_013.txt` — -- File: Task.hs
- `snippet_014.hs` — module Task
- `snippet_015.txt` —   ( Task(..)
- `snippet_016.hs` —   ) where
- `snippet_017.hs` — data Task = Task
- `snippet_018.txt` — 
- `snippet_019.hs` — module Task (...) where declares the module’s name and which functions are exported.
- `snippet_020.txt` — Now in Main.hs:
- `snippet_021.hs` — import Task
- `snippet_022.txt` — You can call addTask, markDone, etc., directly.
- `snippet_023.ghci.txt` — By now, you’ve been running functions in GHCi to check results. That works for learning but doesn’t scale. Testing fr...
- `snippet_024.txt` — Install Hspec (later you’ll learn how to use cabal or stack to manage packages).
- `snippet_025.hs` — import Test.Hspec
- `snippet_026.hs` — main :: IO ()
- `snippet_027.txt` —       let ts = addTask "Test" []
- `snippet_028.sh` — runhaskell Spec.hs
- `snippet_029.txt` — addTask
- `snippet_030.hs` —  Exercise 1: Define a typeclass PrettyPrint with a function pretty :: a -> String. Make Task an instance.
- `snippet_031.ghci.txt` —  Exercise 3: Write a simple test (even without Hspec) by writing a function test = square 3 == 9 and evaluating test ...
- `snippet_032.txt` —  That’s Part 1 of Chapter 12 (about 1,000 words).
- `snippet_033.hs` — End-of-chapter “Try It Yourself” challenge: refactor the to-do CLI into modules, add a PrettyPrint typeclass for task...
- `snippet_034.txt` — Build and run a complete mini-project.
- `snippet_035.hs` — Maybe: A type that represents an optional value (Just something or Nothing).
- `snippet_036.txt` — -- Binding
- `snippet_037.hs` — import qualified Data.Map as Map
- `snippet_038.txt` — 
- `snippet_039.hs` — main :: IO ()
- `snippet_040.txt` —   putStrLn "Enter your name:"
- `snippet_041.hs` — The next book in this series — Intermediate Haskell: Typeclasses, Modules, and Beyond — will pick up where this one l...
- `snippet_042.txt` — To receive your materials, please send an email to info@lincolnpublishers.us with the subject line Companion Resource...
- `snippet_043.hs` — Go to the Amazon page where you purchased this book.
- `snippet_044.txt` — It doesn’t need to be long. Even a few sentences go a long way in helping other readers make informed choices and let...